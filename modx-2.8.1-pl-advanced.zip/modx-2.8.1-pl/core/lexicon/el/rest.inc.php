<?php
/**
 * REST lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['error'] = 'Σφάλμα!';
$_lang['rest.err_class_remove'] = 'Παρουσιάστηκε σφάλμα κατά τη διαγραφή του [[+class_key]]';
$_lang['rest.err_class_save'] = 'Παρουσιάστηκε σφάλμα κατά την προσπάθεια αποθήκευσης του [[+class_key]]';
$_lang['rest.err_field_ns'] = 'Δεν έχετε προσδιορίσει το [[+field]]!';
$_lang['rest.err_field_required'] = 'Αυτό το πεδίο είναι υποχρεωτικό.';
$_lang['rest.err_fields_required'] = 'Η συμπλήρωση των παρακάτω πεδίων είναι υποχρεωτική: [[+fields]]';
$_lang['rest.err_obj_nf'] = 'Δεν βρέθηκε το [[+class_key]]!';
