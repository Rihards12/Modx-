<?php
/**
 * Welcome English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['modx_news'] = 'MODX uudised';
$_lang['security_notices'] = 'Turvalisuse Teated';
$_lang['welcome_messages'] = 'Teie Inbox sisaldab <strong>%d</strong> teadet(eid), millest <strong>%s</strong> on lugemata.';
$_lang['welcome_title'] = 'Teretulemast teie MODX Sisuhaldussüsteemi';
$_lang['yourinfo_message'] = 'See osa näitab intot teie kohta:';
$_lang['yourinfo_previous_login'] = 'Teie viimane sisselogimine:';
$_lang['yourinfo_title'] = 'Teie info';
$_lang['yourinfo_total_logins'] = 'Sisselogitud kordi kokku:';
$_lang['yourinfo_username'] = 'Oled sisselogitud kui:';