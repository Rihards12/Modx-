<?php
/**
 * Mail English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = 'Du skal angive en e-mail-adresse til at sende til.';
$_lang['mail_err_derive_getmailer'] = 'Forsøgte at kalde den abstrakte funktion _getMailer() i modMail-klassen. Du skal implementere denne funktion i en klasse der nedarver fra modMail-klassen.';
$_lang['mail_err_attr_nv'] = '[[+attr]] er ikke en gyldig PHPMailer-attribut og bliver ignoreret af implementeringen.';
$_lang['mail_err_unset_spec'] = 'modPHPMailer kan ikke fjerne specifikke adresser. Brug reset() for at fjerne alle modtagere og tilføj derefter dem du vil sende til.';